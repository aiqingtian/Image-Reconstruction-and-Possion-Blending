clc;
clear;
close all;

% imgin = im2double(imread('./target.jpg'));
imgin = im2double(imread('target.jpg'));
% imgin = imrotate(imgin, 180);

[imh, imw, nb] = size(imgin);
assert(nb==1);
% the image is grayscale

V = zeros(imh, imw);
V(1:imh*imw) = 1:imh*imw;
% V(y,x) = (y-1)*imw + x
% use V(y,x) to represent the variable index of pixel (x,y)
% Always keep in mind that in matlab indexing starts with 1, not 0

%TODO: initialize counter, A (sparse matrix) and b.
A = sparse([],[],[]);
b = zeros(imh*imw+4, 1);
%-----

%TODO: fill the elements in A and b, for each pixel in the image
e = 1;
for y = 1:imh
    for x = 1:imw
        A(e, V(y, x)) = 4;
        
        if(y == 1)
            if(x == 1 || x == imw)
                A(e, V(y, x)) = 0; 
                b(e) = b(e) + 0;
            else
                A(e, V(y, x-1)) = 1;
                A(e, V(y, x)) = -1;
                b(e) = b(e) + imgin(y, x-1) - imgin(y, x);
            end
        elseif(y == imh)
            if(x == 1 || x == imw)
                A(e, V(y, x)) = 0;
                b(e) = b(e) + 0;
            else
                A(e, V(y, x-1)) = 1;
                A(e, V(y, x)) = -1;
                b(e) = b(e) + imgin(y, x-1) - imgin(y, x);
            end
        elseif(x == 1 || x == imw)
            if(y ~= 1 && y ~= imh)
                A(e, V(y - 1, x)) = 1;
                A(e, V(y, x)) = -1;
                b(e) = b(e) + imgin(y - 1, x) - imgin(y, x);
            end
        else
            A(e, V(y - 1, x)) = -1;
            b(e) = b(e) - imgin(y - 1, x) + imgin(y, x);
            A(e, V(y + 1, x)) = -1;
            b(e) = b(e) + imgin(y, x) - imgin(y + 1, x);
            A(e, V(y, x-1)) = -1;
            b(e) = b(e) + imgin(y, x) - imgin(y, x - 1);
            A(e, V(y, x + 1)) = -1;
            b(e) = b(e) + imgin(y, x) - imgin(y, x + 1);
        end 
        e = e + 1;
    end 
end
            
            

%TODO: add extra constraints
A(e+3, V(imh, imw)) = 1;
b(e+3) = b(e+3) + imgin(imh, imw);
A(e, V(1, 1)) = 1;
% b(e) = b(e) + imgin(1, 1)+0.3;
b(e) = b(e) + imgin(1, 1);
A(e+1, V(1, imw)) = 1;
b(e + 1) = b(e+1)+imgin(1, imw);
A(e+2, V(imh, 1)) = 1;
b(e+2) = b(e+2)+ imgin(imh, 1);



%TODO: solve the equation
%use "lscov" or "\", please google the matlab documents
% b = b.';
% solution = lscov(A, b);
solution = A \b;

error = sum(abs(A*solution-b));
disp(error)
imgout = reshape(solution,[imh,imw]);
% imgout = imrotate(imgout, 180);
% imwrite(imgout,'target2.jpg');
imwrite(imgout,'output.png');

figure(), hold off, imshow(imgout);

